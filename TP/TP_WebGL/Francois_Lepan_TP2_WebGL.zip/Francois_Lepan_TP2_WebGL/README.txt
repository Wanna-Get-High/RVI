Francois Lepan

Tout est fait.

avancer 			: w
reculer 			: s
pas de coté gauche 	: a
pas de coté droit 	: d

tourner à gauche 	: j
tourner à droite 	: l
lever la tête 		: k
baisser la tête  	: i