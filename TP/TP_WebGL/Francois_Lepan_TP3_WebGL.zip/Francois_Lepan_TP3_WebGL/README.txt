Francois Lepan

Tout est fait. J'ai eu quelques soucis pour comprendre les méthodes à utiliser pour ce TP (documentation Three.js -> pauvre).
Sinon TP intéressant et une bonne révision pour les changement de repère :)


avancer 			: w
reculer 			: s
pas de coté gauche 	: a
pas de coté droit 	: d

tourner à gauche 	: j
tourner à droite 	: l
lever la tête 		: k
baisser la tête  	: i


